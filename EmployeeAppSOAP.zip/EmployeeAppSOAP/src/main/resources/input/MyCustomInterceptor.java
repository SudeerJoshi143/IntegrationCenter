package input;
import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.interceptor.Interceptor;
import org.mule.processor.AbstractInterceptingMessageProcessor;

public class MyCustomInterceptor extends AbstractInterceptingMessageProcessor implements Interceptor
{
    
    @Override
    public MuleEvent process(MuleEvent event) throws MuleException
    {
    	System.out.println("EVENET"+event+"messgae"+event.getMessage());
		return event;
       
    }

}