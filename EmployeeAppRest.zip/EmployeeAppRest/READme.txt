For Running API,

POST METHOD:

Call this URl from Postman :
localhost:8081/api/employee

With Request

{
"employeeId:"123",
"employeeName":"xxx",
"Age":"24"
}

Response:
{
Employee Details Added
}

GET METHOD

Request:
localhost:8081/api/employee?employeeId=111


Response:
{
    "employeeId": "111",
    "employeeName": "devi",
    "Age": "26",
    "address": {
        "building": "5B",
        "location": "ecoworld",
        "city": "Bangalore",
        "pin": "560103"
    }
}

ExperienceAPI Running on Port 8081
ProcessAPI Running on Port 8082
SystemAPIEmployee Running On Port 8083
SystemAPIAddress Running on Port 8084
LoggingAPI Running on Port 8080
Exception Handler Running On Port 8085

For Exception Handling,

If any of the component fails or any service is down, the flow will go to the catch Exception Strategy,

In Catch Exception Strategy, we are logging the error message through loggingAPI microservices and also we are setting the payload for error and also transforming that error message using Exception component microservice

Response of the Exception is,

{
    "httpStatus": "500",
    "apiName": "Exception",
    "error": {
        "errorCode": "3004",
        "message": "Table 'logsdb.xxx' doesn't exist (com.mysql.jdbc.exceptions.jdbc4.MySQLSyntaxErrorException).",
        "resourceURL": "/api/system/employee"
    }
}
